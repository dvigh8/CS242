public abstract class Encryptor {
	
	private String encrypted = new String(); // a string to store the enctrypted or decrypted message in 
	
	public void textEncrypt(String Input){} 
	
	public void textDecrypt(String Input, int key){}

}